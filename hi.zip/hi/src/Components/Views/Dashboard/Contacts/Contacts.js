import React from 'react';

const Contacts = () => {
    return(
        <center>
            <div>Contacts</div>
        </center>
    );
}

export default Contacts;