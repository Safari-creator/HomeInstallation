import React from 'react'

function ForgotPassword() {
    return (
        <div>
            Forgot Password
        </div>
    )
}

export default ForgotPassword
