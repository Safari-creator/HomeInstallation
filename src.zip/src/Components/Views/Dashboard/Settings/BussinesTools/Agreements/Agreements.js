import React from 'react'

function Agreement() {
    return (
        <div>
            I am agreement
        </div>
    )
}

export default Agreement
