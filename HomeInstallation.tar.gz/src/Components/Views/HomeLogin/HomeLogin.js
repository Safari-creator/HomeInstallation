import React from 'react'
import './HomeLogin.css'
import logo from '../../../Assets/images/aurora-big-logo.png';

function HomeLogin() {
    return (
        <div className="grey-background">
            <img src={logo} alt="logo" />
        </div>
    )
}

export default HomeLogin
